$("#g-confirm-delete").submit(
  function() {
    $("#g-confirm-delete input[type=submit]").gallery_show_loading();
  }
);
