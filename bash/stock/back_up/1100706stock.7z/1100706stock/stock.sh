#!/bin/bash
#1100628想要寫一個能下載網頁資料來計算股票高、低、合理價的腳本，網路上有很多大德的成果，但是多是把全部資料下載回來，再做更進一步的技術分析，但這對我這種只想賺股利、股息的人來說，那些功能都太多了，所以寫個腳本來試著提昇功力吧。

#function
summe(){
	file=$1.txt
	s=0
	while read line2
	do
		s=$(echo $s+$line2|bc)
	done < $file
	return 1		
}


#main
file=db.txt
while read line
do
	wget --user-agent="Mozilla/5.0 （Windows; U; Windows NT 6.1; en-US） AppleWebKit/534.16 （KHTML， like Gecko） Chrome/10.0.648.204 Safari/534.16" -nv --tries=5 --timeout=5 -O $line.html https://www.stockinfo.tw/?stockSearch=$line
	sleep 300
	price=$(cat $line.html | grep 成交價|head -n 3|tail -n 1|cut -d '>' -f 4|cut -d '<' -f 1)
	(cat $line.html |grep '"配息(元/股)">'|cut -d '>' -f 2|cut -d '<' -f 1|head -n 10) > $line-dividend_1.txt
	(cat $line.html |grep '"配股(元/百股)">'|cut -d '>' -f 2|cut -d '<' -f 1|head -n 10) > $line-dividend_2.txt
	summe $line-dividend_1
	s1=$s
	summe $line-dividend_2
	s2=$s
	s2=$(echo 'scale=2;'$s2/10|bc -l)
	s3=$(echo 'scale=2;'$s1+$s2|bc -l)
	s3=$(echo 'scale=2;'$s3/10|bc -l)
	echo $s3
	sl=$(echo 'scale=2;'$s3*16|bc -l)
	sok=$(echo 'scale=2;'$s3*20|bc -l)
	sh=$(echo 'scale=2;'$s3*32|bc -l)
	echo $sl,$sok,$sh
	if [ $(echo "$price >= $sh"|bc -l) -eq 1 ] 
	then
		st="too high"

	elif [ $(echo "$price < $sh"|bc -l) -eq 1 ] && [ $(echo "$price > $sok"|bc -l) -eq 1 ]
	then
		st="wait"
	elif [ $(echo "$price < $sok"|bc -l) -eq 1 ] && [ $(echo "$price > $sl"|bc -l) -eq 1 ]
	then
		st="OK"
	elif [ $(echo "$price <= $sl"|bc -l) -eq 1 ]
	then
		st="low"
	else
		echo "simothing wrong"
	fi
	echo $line,$price,$st
	echo $line,$price,$st >> sol.txt
done < $file

mv sol.txt $(date '+%Y%m%d')sol.log
mkdir dividend
mv *-dividend_?.txt ./dividend/
mkdir stock
mv *.html ./stock
